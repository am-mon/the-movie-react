import React, { useState } from "react";

const Pagination = ({ totalPages, currentPage, onPageChange }) => {
  const pages = Array.from({ length: totalPages }, (_, index) => index + 1);
  console.log("Pages: " + pages);

  return (
    <>
      <ul className="flex my-10 items-center">
        {currentPage > 1 && (
          <li className="m-1">
            <span
              onClick={() => onPageChange(currentPage - 1)}
              className="cursor-pointer"
            >
              Previous
            </span>
          </li>
        )}

        {pages?.map((pageNumber, index) => {
          return (
            <li key={index} className="m-1">
              <span
                onClick={() =>
                  onPageChange(pageNumber, currentPage == pageNumber)
                }
                className={`${
                  currentPage == pageNumber
                    ? "active bg-emerald-700"
                    : "bg-emerald-500"
                } hover:bg-emerald-700 text-white w-[30px] h-[30px] block text-[15px] text-center leading-[30px] cursor-pointer`}
              >
                {pageNumber}
              </span>
            </li>
          );
        })}
        {currentPage < pages.length && (
          <li className="m-1">
            <span
              onClick={() => onPageChange(currentPage + 1)}
              className="cursor-pointer"
            >
              Next
            </span>
          </li>
        )}
      </ul>
    </>
  );
};

export default Pagination;
