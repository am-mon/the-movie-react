const MovieCard = ({ movie, className }) => {
  return (
    <div className={className}>
      <div className="w-full">
        {/* <Link to={`/detail/${movie.id}`}> */}
        <img
          src={`https://image.tmdb.org/t/p/original/${movie.poster_path}`}
          className="rounded"
        />
        {/* </Link> */}
        <h4 className="my-2 text-center text-base md:text-lg">{movie.title}</h4>
      </div>
    </div>
  );
};

export default MovieCard;
