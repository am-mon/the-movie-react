import { useEffect, useState } from "react";
import Section from "./Section";
import MovieCard from "./MovieCard";
import Pagination from "./Pagination";

const Home = () => {
  const [movieList, setMovieList] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);

  useEffect(() => {
    fetchMovies();
  }, [page]);

  const fetchMovies = async () => {
    const api = await fetch(
      `https://api.themoviedb.org/3/movie/upcoming?api_key=c05d1c927a4b60ec1fff7ff01f5c3d8d&language=en-US&page=${page}`
    );
    const response = await api.json();
    console.log(response);
    setMovieList(response.results);
    setTotalPages(response.total_pages);
  };

  return (
    <>
      <Section>
        <Pagination
          totalPages={totalPages}
          onPageChange={(page) => setPage(page)}
          currentPage={page}
        />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {movieList?.map((movie) => {
            return <MovieCard key={movie.id} movie={movie} className="" />;
          })}
        </div>
      </Section>
    </>
  );
};

export default Home;
