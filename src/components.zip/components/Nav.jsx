import { Link } from "react-router-dom";

const Nav = () => {
  return (
    <>
      <div className="bg-emerald-700 text-white box-border py-6 ">
        <div className="container mx-auto px-3 flex justify-between items-center">
          <h1 className="font-title-font-01 text-5xl font-normal">
            <Link to="/">MovieFlix</Link>
          </h1>
          <ul className="flex items-center text-lg">
            <li className="mr-10">
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default Nav;
