import Section from "./Section";

const Contact = () => {
  return (
    <>
      <Section>Contact</Section>
    </>
  );
};

export default Contact;
